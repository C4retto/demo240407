基于 NCMOEA 的初始化生成的
label-based representation
生成
locus-based representation
.
