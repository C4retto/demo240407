function locus_best = LocalSearch(p, locus)
	locus_best = locus;
	label = Decode(locus);
	shuffle = randperm(p.numVar);
	for n = shuffle
		condLabel = setdiff(unique(label.*p.adj(n,:)),0);
		temp = label;
		maxDeltaQ = 0;
		maxlabel = label(n);
		for c = condLabel
			temp(n) = c;
			if temp(n) ~= label(n)
				deltaQ = DeltaModularity(p.adj,p.degree,n,label,temp);
				if deltaQ > maxDeltaQ
					maxDeltaQ = deltaQ;
					maxlabel = c;
				end
			end
		end
		if maxDeltaQ > 0
			% 随机选择该社区中的邻点
			locus_best(n) = randsample(find(p.adj(n,:) & label==maxlabel),1);  
			label(n) = maxlabel;
		end
	end
end